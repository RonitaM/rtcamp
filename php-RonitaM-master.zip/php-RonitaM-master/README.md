# php-RonitaM
php-RonitaM created by GitHub Classroom


This is my first post on git platform, and github hence my coding might be a bit murky and this representation a bit lousy. Please do ignore that.

Problem Statement:

Your app should include email verification to avoid people using others’ email addresses.
XKCD image should go as an email attachment as well as inline image content.
You can visit https://c.xkcd.com/random/comic/ programmatically to return a random comic URL and then use JSON API for details https://xkcd.com/json.html
Please make sure your emails contain an unsubscribe link so a user can stop getting emails.
Since this is a simple project it must be done in core PHP including API calls, recurring emails, including attachments should happen in core PHP. Please do not use any libraries.


Solution:

First.php: A basic webpage(without any styling techniques) to ask for user input email address. On clicking the subscribe button, the page redirects to second.php where a token is generated using rand() function and md5() algorith,
This token is stored in the database and a verification email sent along with the token number.

On clicking the verification link, input is validated using token based input. This enables checking for user emails such that user doesnt use anyone's email address for spamming.

XKCD image is sent using email attachment(pdf and html file) and an inline image content(href)

Unsubscribe link is given to delete the user from the mailing list- unsub.php

A single database and a single table users is used for the entire system.

A job is created that sends the email to all the verified users every five minutes.

****SQL Code:

create database rtcamp;

CREATE TABLE `users` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `email` varchar(100) NOT NULL,
 `verified` tinyint(1) NOT NULL DEFAULT '0',
 `token` varchar(255) DEFAULT NULL,
 PRIMARY KEY (`id`)
)

**End of SQL**

If you have any other query please feel free to reach out at ronitamitra14@gmail.com

Thank you.
